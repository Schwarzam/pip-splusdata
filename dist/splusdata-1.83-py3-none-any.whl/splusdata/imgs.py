from PIL import Image
import requests
from io import BytesIO
import numpy as np
import matplotlib.pyplot as plt

def get_img_obj(Survey, Field, ID, filename=None):
    url = f'http://127.0.0.1:8000/media/{Survey}/{Field}/{ID}.jpg'
    response = requests.get(url)
    img = Image.open(BytesIO(response.content))


    if filename:
        img2 = np.array(img)
        plt.imsave(arr=img2, fname=filename)

    return img
