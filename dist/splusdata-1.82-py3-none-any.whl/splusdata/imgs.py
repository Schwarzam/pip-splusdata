
def get_img_obj(Survey, Field, ID, filename=None):
    url = f'http://127.0.0.1:8000/media/{Survey}/{field}/{ID}.jpg'
    response = requests.get(url)
    img = Image.open(BytesIO(response.content))
    
    if filename:
        plt.imsave(arr=np.array(img), fname=filename)

    return img
